module HelloWorld
  def self.say_hello
    puts 'hello world'
  end
end